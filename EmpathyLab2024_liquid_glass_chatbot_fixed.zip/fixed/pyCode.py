def runThis():
    print("This is running")