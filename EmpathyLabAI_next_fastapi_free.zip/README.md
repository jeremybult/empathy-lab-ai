# Empathy Lab AI: Free Full-Stack Starter

This is a free-tool starter for a production-shaped build:

- `frontend/`: Next.js app for the public site and live chatbot UI
- `backend/`: FastAPI API for personas, chat, health checks, and reset
- browser speech recognition + browser speech synthesis to avoid per-reply cloud TTS costs
- ready for a hosted chatbot on a subdomain such as `app.yourdomain.com`

## Recommended free setup

Because free hosting plans change often and I cannot verify live plan limits in this environment, treat these as common low-cost patterns rather than guaranteed current free tiers:

- Frontend: Vercel or Netlify
- Backend: Render, Railway, Fly.io, or another Python host
- Domain DNS: Cloudflare (or your registrar DNS)
- Optional local database later: Supabase / Neon / SQLite

## Project structure

```text
frontend/
backend/
```

## What this starter includes

- Liquid-glass inspired homepage and chatbot layout
- Persona switching for Andrea Miller, Dr. Candice Martinez, and Cooper Litt
- Chat endpoint with demo fallback when `OPENAI_API_KEY` is missing
- Session-style memory keyed by a browser-generated client ID
- Voice input using browser speech recognition where supported
- Voice output using browser speech synthesis
- Deployment notes for running the chatbot on a subdomain

## Local development

### 1) Backend

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
uvicorn app.main:app --reload --port 8000
```

### 2) Frontend

```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev
```

Frontend runs on `http://localhost:3000`
Backend runs on `http://localhost:8000`

## Environment variables

### Backend `.env`

```env
OPENAI_API_KEY=
OPENAI_MODEL=gpt-4o-mini
ALLOWED_ORIGINS=http://localhost:3000
```

`OPENAI_MODEL` is configurable on purpose. Set it to any model your account supports.

### Frontend `.env.local`

```env
NEXT_PUBLIC_API_BASE_URL=http://localhost:8000
NEXT_PUBLIC_APP_NAME=Empathy Lab AI
```

## Subdomain deployment pattern

Use the marketing site on the root domain and the chatbot app on a subdomain.

Example:

- `https://empathylabai.org` -> marketing site / landing page
- `https://app.empathylabai.org` -> live chatbot app
- `https://api.empathylabai.org` -> backend API, if you want a separate API subdomain

Simplest free pattern:

- Deploy Next.js frontend to Vercel
- Deploy FastAPI backend to a Python host
- Point `app.` to the frontend
- Point `api.` to the backend
- Set `NEXT_PUBLIC_API_BASE_URL=https://api.empathylabai.org`
- Add the deployed frontend origin to `ALLOWED_ORIGINS`

## Notes on voice

This starter avoids per-reply cloud TTS billing by using built-in browser speech synthesis.

That means:

- no ElevenLabs call per message
- no premium cloned voice out of the box
- much lower cost during development and demos

If you later want a premium voice, add it as an optional mode, not the default runtime path.

## Notes on persistence

This starter uses in-memory conversation storage for simplicity and cost.

That is fine for local use and demos.
For production, move chat history to a database such as Postgres, Supabase, or Redis.

## Suggested next upgrades

- add authentication
- add database-backed chat history
- add analytics and conversation logging
- add RAG or source-grounded responses
- add rate limiting
- add moderation
- add persona admin panel
