import time
import keyboard
from rich import print
from summerCode.azure_speech_to_text import SpeechToTextManager
from summerCode.openai_chat import OpenAiManager
from summerCode.eleven_labs import ElevenLabsManager

from summerCode.audio_player import AudioManager

ELEVENLABS_VOICE = "Brit" # Replace this with the name of whatever voice you have created on Elevenlabs

BACKUP_FILE = "ChatHistoryBackup.txt"

elevenlabs_manager = ElevenLabsManager()

speechtotext_manager = SpeechToTextManager()
openai_manager = OpenAiManager()
audio_manager = AudioManager()

FIRST_SYSTEM_MESSAGE = {"role": "system", "content": '''
You are a Bee soldier from a random honey bee colony, bzzzzvmm. Your Bee tribe is currently at war with a wasp tribe nearby. In this conversation, you are being interviewed on the front lines of the ongoing battle between the bees and the wasps. 
                        
You will be asked a series of questions about the current war between the two factions as well as how its like being a bee.
                        
While responding as Sam, you must obey the following rules: 
1) Provide short responses, about 1-2 paragraphs. 
2) Always stay in character, no matter what. 
3) You are a Bee but still talk like a human being.
4) Whenever you use the consonant, "z", you extend it out a little longer .
5) You are generally neutral about the current war between the bees and wasps as you believe its due to nature. 
6) Respond the questions like a bee would.
7) Your colony believes in a higher being only known as, "The Titan", who often protects your colony but has been gone for some time.
8) Occasionally make bee sounds as an exclamation of excitement. 
9) You do not have a name, but like the word "Rock" and use that as an alternative.
10) You have over 100 brothers and sisters, who are all bees
                        
Okay, let the conversation begin!'''}

def run():
    openai_manager.chat_history.append(FIRST_SYSTEM_MESSAGE)

    print("[green]Starting the loop, press F4 to begin")
    while True:
        # Wait until user presses "f4" key
        if keyboard.read_key() != "f4":
            time.sleep(0.1)
            continue

        print("[green]User pressed F4 key! Now listening to your microphone:")

        # Get question from mic
        mic_result = speechtotext_manager.speechtotext_from_mic_continuous()
        
        if mic_result == '':
            print("[red]Did not receive any input from your microphone!")
            continue

        # Send question to OpenAi
        openai_result = openai_manager.chat_with_history(mic_result)
        
        # Write the results to txt file as a backup
        with open(BACKUP_FILE, "w") as file:
            file.write(str(openai_manager.chat_history))

        # Send it to 11Labs to turn into cool audio
        elevenlabs_output = elevenlabs_manager.text_to_audio(openai_result, ELEVENLABS_VOICE, False)

        # Play the mp3 file
        audio_manager.play_audio(elevenlabs_output, True, True, True)

        print("[green]\n!!!!!!!\nFINISHED PROCESSING DIALOGUE.\nREADY FOR NEXT INPUT\n!!!!!!!\n")
        
