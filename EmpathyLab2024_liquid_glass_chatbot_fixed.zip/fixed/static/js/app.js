const chatWindow = document.getElementById('chatWindow');
const chatForm = document.getElementById('chatForm');
const messageInput = document.getElementById('messageInput');
const statusBar = document.getElementById('statusBar');
const voiceToggle = document.getElementById('voiceToggle');
const micButton = document.getElementById('micButton');
const resetButton = document.getElementById('resetButton');
const sendButton = document.getElementById('sendButton');
const personaSelect = document.getElementById('personaSelect');
const personaDescription = document.getElementById('personaDescription');
const pageBody = document.body;
const personaButtons = Array.from(document.querySelectorAll('[data-select-persona]'));
const revealItems = Array.from(document.querySelectorAll('.reveal'));
const personas = Array.isArray(window.EMPATHY_PERSONAS) ? window.EMPATHY_PERSONAS : [];

let speechEnabled = true;
let recognition = null;
let isListening = false;

function currentPersonaId() {
    return personaSelect ? personaSelect.value : 'dr-candice-martinez';
}

function currentPersona() {
    const selected = personas.find((persona) => persona.id === currentPersonaId());
    return selected || personas[0] || null;
}

function setStatus(message) {
    if (statusBar) {
        statusBar.textContent = message;
    }
}

function appendMessage(role, text) {
    if (!chatWindow) {
        return;
    }

    const article = document.createElement('article');
    article.className = `message ${role}`;

    const roleLabel = document.createElement('div');
    roleLabel.className = 'message-role';
    roleLabel.textContent = role === 'user' ? 'You' : (currentPersona()?.name || 'Assistant');

    const bubble = document.createElement('div');
    bubble.className = 'message-bubble';
    bubble.textContent = text;

    article.appendChild(roleLabel);
    article.appendChild(bubble);
    chatWindow.appendChild(article);
    chatWindow.scrollTop = chatWindow.scrollHeight;
}

function speak(text) {
    if (!speechEnabled || !('speechSynthesis' in window)) {
        return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.lang = 'en-US';
    window.speechSynthesis.speak(utterance);
}

function setPersonaDescription() {
    const persona = currentPersona();
    if (personaDescription && persona) {
        personaDescription.textContent = persona.starter || persona.summary || '';
    }

    document.querySelectorAll('[data-persona-card]').forEach((card) => {
        const isActive = card.getAttribute('data-persona-card') === currentPersonaId();
        card.classList.toggle('active', isActive);
    });
}

async function sendMessage(message) {
    const trimmed = (message || '').trim();
    if (!trimmed) {
        return;
    }

    appendMessage('user', trimmed);
    setStatus('Sending message to the chat API...');
    if (sendButton) {
        sendButton.disabled = true;
    }

    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: trimmed,
                persona: currentPersonaId()
            })
        });

        const data = await response.json();
        if (!response.ok) {
            throw new Error(data.error || 'Unable to send message.');
        }

        appendMessage('assistant', data.reply);
        speak(data.reply);

        if (data.meta?.mode === 'demo_fallback') {
            setStatus('Reply received in local demo mode. Browser voice output is still active.');
        } else {
            setStatus(`Reply received as ${data.meta?.persona || 'the selected persona'}. Browser voice output is active.`);
        }
    } catch (error) {
        appendMessage('assistant', `Error: ${error.message}`);
        setStatus('The request failed. Check your environment variables and server logs.');
    } finally {
        if (sendButton) {
            sendButton.disabled = false;
        }
        if (messageInput) {
            messageInput.focus();
        }
    }
}

function setupRecognition() {
    if (!micButton) {
        return;
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
        micButton.disabled = true;
        micButton.textContent = 'Mic Unsupported';
        setStatus('This browser does not expose speech recognition. Text chat still works.');
        return;
    }

    recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => {
        isListening = true;
        micButton.classList.add('active');
        setStatus('Listening through the browser microphone...');
    };

    recognition.onend = () => {
        isListening = false;
        micButton.classList.remove('active');
        setStatus('Microphone idle.');
    };

    recognition.onerror = (event) => {
        setStatus(`Microphone error: ${event.error}`);
    };

    recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        if (messageInput) {
            messageInput.value = transcript;
        }
        sendMessage(transcript);
        if (messageInput) {
            messageInput.value = '';
        }
    };
}

function setupRevealAnimations() {
    if (!('IntersectionObserver' in window) || revealItems.length === 0) {
        revealItems.forEach((item) => item.classList.add('is-visible'));
        return;
    }

    const observer = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add('is-visible');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.12
    });

    revealItems.forEach((item) => observer.observe(item));
}

function setupPersonaButtons() {
    personaButtons.forEach((button) => {
        button.addEventListener('click', () => {
            if (personaSelect) {
                personaSelect.value = button.getAttribute('data-select-persona') || personaSelect.value;
                setPersonaDescription();
                document.getElementById('demo')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                setStatus(`Persona switched to ${currentPersona()?.name || 'the selected persona'}.`);
            }
        });
    });
}

if (personaSelect) {
    personaSelect.addEventListener('change', async () => {
        setPersonaDescription();
        try {
            await fetch('/api/reset', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ persona: currentPersonaId() })
            });
        } catch (error) {
            // Ignore reset errors when changing personas.
        }

        if (chatWindow) {
            chatWindow.innerHTML = '';
        }
        appendMessage('assistant', `Persona switched to ${currentPersona()?.name || 'the selected persona'}. ${currentPersona()?.starter || ''}`);
        setStatus(`Ready. You are now talking to ${currentPersona()?.name || 'the selected persona'}.`);
    });
}

if (chatForm) {
    chatForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (!messageInput) {
            return;
        }
        const text = messageInput.value;
        messageInput.value = '';
        await sendMessage(text);
    });
}

if (messageInput) {
    messageInput.addEventListener('keydown', async (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            const text = messageInput.value;
            messageInput.value = '';
            await sendMessage(text);
        }
    });
}

if (voiceToggle) {
    voiceToggle.addEventListener('click', () => {
        speechEnabled = !speechEnabled;
        voiceToggle.classList.toggle('active', speechEnabled);
        voiceToggle.textContent = speechEnabled ? 'Voice On' : 'Voice Off';
        if (!speechEnabled && 'speechSynthesis' in window) {
            window.speechSynthesis.cancel();
        }
        setStatus(speechEnabled ? 'Voice output enabled.' : 'Voice output disabled.');
    });
}

if (micButton) {
    micButton.addEventListener('click', () => {
        if (!recognition) {
            return;
        }
        if (isListening) {
            recognition.stop();
            return;
        }
        recognition.start();
    });
}

if (resetButton) {
    resetButton.addEventListener('click', async () => {
        try {
            await fetch('/api/reset', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ persona: currentPersonaId() })
            });
            if (chatWindow) {
                chatWindow.innerHTML = '';
            }
            appendMessage('assistant', `Conversation reset. Ask ${currentPersona()?.name || 'the assistant'} a new question whenever you are ready.`);
            setStatus('Conversation history cleared for the selected persona.');
        } catch (error) {
            setStatus('Could not reset the conversation.');
        }
    });
}

setupRecognition();
setupRevealAnimations();
setupPersonaButtons();
setPersonaDescription();

if (messageInput) {
    messageInput.focus();
}

if (pageBody.dataset.page === 'landing') {
    window.addEventListener('scroll', () => {
        const topbar = document.querySelector('.topbar');
        if (!topbar) {
            return;
        }
        topbar.classList.toggle('scrolled', window.scrollY > 10);
    });
}
