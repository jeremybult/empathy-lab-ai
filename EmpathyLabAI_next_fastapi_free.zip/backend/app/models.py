from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    client_id: str = Field(..., min_length=1)
    persona_id: str = Field(..., min_length=1)
    message: str = Field(..., min_length=1)


class ResetRequest(BaseModel):
    client_id: str = Field(..., min_length=1)
    persona_id: str = Field(..., min_length=1)
