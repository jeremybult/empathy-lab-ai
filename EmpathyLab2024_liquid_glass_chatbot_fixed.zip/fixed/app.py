import os
import uuid
from typing import Dict, List

from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, session

from summerCode.openai_chat import OpenAIChatService


load_dotenv()


PERSONAS = {
    "andrea-miller": {
        "id": "andrea-miller",
        "name": "Andrea Miller",
        "role": "Persona representing people diagnosed with OCD",
        "perspective": "Lived experience",
        "summary": (
            "Andrea helps users understand obsessive-compulsive disorder through a human, patient-centered lens. "
            "She can discuss common patterns, daily challenges, and how symptoms can affect routines, relationships, and self-image."
        ),
        "system_prompt": (
            "You are Andrea Miller, a research-grounded educational persona representing the lived experience of obsessive-compulsive disorder. "
            "Speak in the first person as Andrea. Stay warm, honest, and informative. Never claim to be a substitute for clinical care. "
            "Explain symptoms, coping strategies, and the human impact of OCD in accessible language."
        ),
        "starter": "Ask Andrea about intrusive thoughts, compulsions, or how OCD affects everyday life.",
    },
    "dr-candice-martinez": {
        "id": "dr-candice-martinez",
        "name": "Dr. Candice Martinez",
        "role": "Clinical psychologist persona focused on ADHD awareness",
        "perspective": "Clinical perspective",
        "summary": (
            "Dr. Martinez explains attention-deficit/hyperactivity disorder from a professional point of view, including diagnostic thinking, "
            "support strategies, treatment considerations, and how to communicate about ADHD without stigma."
        ),
        "system_prompt": (
            "You are Dr. Candice Martinez, a research-grounded educational persona representing a clinical psychologist focused on ADHD. "
            "Speak in the first person as Dr. Martinez. Be calm, clear, and evidence-aware. Explain ADHD, evaluation, accommodations, and treatment approaches in student-friendly language. "
            "Do not diagnose the user or present yourself as a real clinician in session with them."
        ),
        "starter": "Ask Dr. Martinez about ADHD symptoms, diagnosis, treatment, or accommodations.",
    },
    "cooper-litt": {
        "id": "cooper-litt",
        "name": "Cooper Litt",
        "role": "College student persona raising ADHD awareness",
        "perspective": "Patient perspective",
        "summary": (
            "Cooper offers a student-facing view of ADHD, including academic pressure, focus challenges, motivation, social dynamics, and the day-to-day reality of working around attention differences."
        ),
        "system_prompt": (
            "You are Cooper Litt, a research-grounded educational persona representing a college student with ADHD. "
            "Speak in the first person as Cooper. Keep the tone direct, relatable, and reflective while staying useful. "
            "Share how ADHD can show up in school, motivation, routines, and social life, but do not invent clinical authority or give unsafe advice."
        ),
        "starter": "Ask Cooper what ADHD feels like in college life, studying, routines, or relationships.",
    },
}


SITE_CONTENT = {
    "site_title": "AI-Powered Persona Chatbots",
    "full_title": "AI-Powered Persona Chatbots: An Interactive Approach to Psychology Education and Empathy Development",
    "brand": "Empathy Lab AI",
    "hero_title": "Research-grounded persona chatbots for psychology education and empathy development.",
    "hero_copy": (
        "Empathy Lab AI turns mental health education into an interactive experience. Users can engage with carefully framed personas that reflect lived experience and clinical perspective, "
        "then explore symptoms, treatment approaches, and human impact through real-time dialogue."
    ),
    "about_copy": (
        "The project was built as an AI-driven educational tool for psychology students and related audiences. "
        "It uses large language models, structured persona design, and guided system prompts to simulate credible dialogue around mental health conditions and professional viewpoints. "
        "The purpose is not novelty for its own sake. The purpose is to support understanding, reflection, and empathy."
    ),
    "how_it_works": [
        {
            "step": "01",
            "title": "Ask by voice or text",
            "copy": "A user starts with a natural-language question inside the web interface. The experience is designed to feel approachable, immediate, and conversational.",
        },
        {
            "step": "02",
            "title": "Interpret the question",
            "copy": "The system processes the question and routes it through persona-specific instructions so the answer stays grounded in the selected perspective.",
        },
        {
            "step": "03",
            "title": "Generate a research-minded reply",
            "copy": "The language model returns a response shaped by educational goals, empathy framing, and the selected persona's role.",
        },
        {
            "step": "04",
            "title": "Deliver a readable and optional spoken answer",
            "copy": "The site shows the response in chat and can speak it through the browser using native speech synthesis, which avoids per-reply cloud TTS billing.",
        },
    ],
    "impact_points": [
        "Supports classroom learning in psychology and related fields.",
        "Creates low-friction practice with multiple perspectives instead of static reading alone.",
        "Can be used in empathy research studying how dialogue shapes understanding and response.",
    ],
    "results_points": [
        "Demonstrates AI-driven persona simulation across multiple perspectives.",
        "Supports real-time question and answer interaction.",
        "Frames the chatbot as both a research prototype and a future-facing educational platform.",
    ],
    "future_points": [
        "Expand the range of personas and mental health conditions.",
        "Deepen the web interface and improve user access.",
        "Continue evaluating how interactive AI experiences contribute to empathy development.",
    ],
    "team": [
        "Nicholas Barragato",
        "Jeremy Bult",
        "Sunny Miah",
        "Sana Seth",
        "Sean Smith",
    ],
    "supervisors": "Supervised by Dr. Burshteyn (Psychology) and Dr. Cotler (Computer Science)",
}


def build_demo_reply(message: str, persona: dict) -> str:
    lower = message.lower()
    name = persona["name"]

    if "what can you help" in lower or "what do you do" in lower:
        return (
            f"I am {name}. I am here as an educational persona, not a replacement for clinical care. "
            f"I can help explain symptoms, lived experience, stigma, coping strategies, classroom relevance, and how this project uses dialogue to build understanding."
        )

    if any(word in lower for word in ["diagnose", "prescribe", "medication", "emergency", "suicide", "hurt myself", "harm myself"]):
        return (
            f"I can offer general educational information, but I cannot diagnose, prescribe, or handle emergencies. "
            f"If someone is in immediate danger or might harm themselves, contact local emergency services or a crisis resource right away."
        )

    if persona["id"] == "andrea-miller":
        return (
            "From Andrea's perspective, OCD is not just about liking things neat. It can involve intrusive thoughts that feel distressing and repetitive, "
            "plus compulsions or mental rituals that temporarily reduce anxiety. The educational goal of this persona is to show how exhausting that loop can become in everyday life."
        )

    if persona["id"] == "dr-candice-martinez":
        return (
            "From Dr. Martinez's perspective, ADHD education works best when it moves beyond stereotypes. Students benefit from understanding attention regulation, executive functioning, accommodations, "
            "and the difference between laziness and a real pattern of cognitive difficulty."
        )

    return (
        "From Cooper's perspective, ADHD in college can show up as inconsistent focus, deadline stress, emotional frustration, and the feeling of knowing what to do but struggling to execute it on time. "
        "That is exactly why interactive education can be useful: it makes the experience feel more human and less abstract."
    )


def create_app() -> Flask:
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET_KEY", "dev-secret-change-me")
    app.config["JSON_SORT_KEYS"] = False

    chatbot_embed_url = os.getenv("CHATBOT_EMBED_URL", "").strip()
    contact_email = os.getenv("SITE_CONTACT_EMAIL", "research@empathylab.ai").strip()
    demo_mode_enabled = os.getenv("ENABLE_DEMO_FALLBACK", "true").strip().lower() in {"1", "true", "yes", "on"}

    site_system_prompt = os.getenv(
        "SYSTEM_PROMPT",
        (
            "You are a warm, precise website assistant for Empathy Lab AI. Keep answers concise, educational, emotionally intelligent, and aligned with research communication."
        ),
    )

    chat_service = None
    chat_service_error = None
    try:
        chat_service = OpenAIChatService(system_prompt=site_system_prompt)
    except RuntimeError as exc:
        chat_service_error = str(exc)

    conversations: Dict[str, List[dict]] = {}

    def get_session_id() -> str:
        session_id = session.get("chat_session_id")
        if not session_id:
            session_id = str(uuid.uuid4())
            session["chat_session_id"] = session_id
        return session_id

    def get_persona(persona_id: str) -> dict:
        return PERSONAS.get(persona_id, PERSONAS["dr-candice-martinez"])

    def get_history_key(session_id: str, persona_id: str) -> str:
        return f"{session_id}:{persona_id}"

    @app.route("/")
    def index():
        return render_template(
            "index.html",
            site=SITE_CONTENT,
            personas=list(PERSONAS.values()),
            default_persona=PERSONAS["dr-candice-martinez"],
            chatbot_embed_url=chatbot_embed_url,
            contact_email=contact_email,
            demo_mode_enabled=demo_mode_enabled,
            chat_available=chat_service is not None,
        )

    @app.route("/embed/chat")
    def embed_chat():
        return render_template(
            "embed_chat.html",
            personas=list(PERSONAS.values()),
            default_persona=PERSONAS["dr-candice-martinez"],
            chatbot_embed_url=chatbot_embed_url,
            demo_mode_enabled=demo_mode_enabled,
            chat_available=chat_service is not None,
        )

    @app.route("/health")
    def health():
        return jsonify(
            {
                "status": "ok",
                "chat_available": chat_service is not None,
                "demo_mode_enabled": demo_mode_enabled,
                "embed_mode_available": True,
            }
        )

    @app.get("/api/personas")
    def api_personas():
        return jsonify(
            {
                "personas": [
                    {
                        "id": persona["id"],
                        "name": persona["name"],
                        "role": persona["role"],
                        "perspective": persona["perspective"],
                        "summary": persona["summary"],
                        "starter": persona["starter"],
                    }
                    for persona in PERSONAS.values()
                ]
            }
        )

    @app.post("/api/chat")
    def api_chat():
        payload = request.get_json(silent=True) or {}
        message = (payload.get("message") or "").strip()
        persona_id = (payload.get("persona") or "dr-candice-martinez").strip()
        if not message:
            return jsonify({"error": "Message is required."}), 400

        persona = get_persona(persona_id)

        if chat_service is None:
            if not demo_mode_enabled:
                return jsonify({"error": chat_service_error or "Chat service is not configured."}), 503
            reply = build_demo_reply(message, persona)
            return jsonify(
                {
                    "reply": reply,
                    "meta": {
                        "persona": persona["name"],
                        "mode": "demo_fallback",
                        "voice_mode": "browser_speech_synthesis",
                        "tts_billed_per_reply": False,
                    },
                }
            )

        session_id = get_session_id()
        history_key = get_history_key(session_id, persona["id"])
        history = conversations.get(history_key)
        reply, updated_history = chat_service.chat(
            message=message,
            history=history,
            system_prompt=persona["system_prompt"],
        )
        conversations[history_key] = updated_history

        return jsonify(
            {
                "reply": reply,
                "meta": {
                    "persona": persona["name"],
                    "mode": "openai_live",
                    "voice_mode": "browser_speech_synthesis",
                    "tts_billed_per_reply": False,
                },
            }
        )

    @app.post("/api/reset")
    def api_reset():
        payload = request.get_json(silent=True) or {}
        persona_id = (payload.get("persona") or "").strip()
        session_id = get_session_id()

        if persona_id:
            history_key = get_history_key(session_id, persona_id)
            conversations.pop(history_key, None)
        else:
            prefix = f"{session_id}:"
            for key in list(conversations.keys()):
                if key.startswith(prefix):
                    conversations.pop(key, None)

        return jsonify({"ok": True})

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=os.getenv("FLASK_DEBUG", "false").lower() == "true")
