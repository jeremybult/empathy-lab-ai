# Free deployment notes for a subdomain chatbot

## Goal

Serve the public app from a subdomain like `app.yourdomain.com`.

## Pattern A: Separate frontend and backend subdomains

- `app.yourdomain.com` -> Next.js frontend
- `api.yourdomain.com` -> FastAPI backend

### Frontend steps

1. Deploy `frontend/` to Vercel.
2. In Vercel project settings, add:
   - `NEXT_PUBLIC_API_BASE_URL=https://api.yourdomain.com`
3. Add the custom domain `app.yourdomain.com`.

### Backend steps

1. Deploy `backend/` to your Python host.
2. Set env:
   - `OPENAI_API_KEY=...`
   - `OPENAI_MODEL=...`
   - `ALLOWED_ORIGINS=https://app.yourdomain.com`
3. Point `api.yourdomain.com` to the backend deployment.

## Pattern B: Marketing root + chatbot subdomain

- `yourdomain.com` -> marketing site
- `app.yourdomain.com` -> chatbot app
- `api.yourdomain.com` -> backend

This keeps the live chatbot distinct from the main site and makes embeds easier later.

## Free-first advice

- Keep voice in the browser, not on the server.
- Use demo fallback until you are ready to pay for live model calls.
- Add a database only when you need persistence.
