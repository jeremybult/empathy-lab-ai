import os

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .models import ChatRequest, ResetRequest
from .services import ChatService

load_dotenv()

app = FastAPI(title="Empathy Lab AI Backend")
service = ChatService()

allowed_origins = [origin.strip() for origin in os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",") if origin.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.get("/api/personas")
def personas() -> dict:
    return {"personas": service.get_personas()}


@app.post("/api/chat")
def chat(request: ChatRequest) -> dict:
    try:
        return service.chat(
            client_id=request.client_id,
            persona_id=request.persona_id,
            message=request.message,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.post("/api/reset")
def reset(request: ResetRequest) -> dict:
    service.reset(client_id=request.client_id, persona_id=request.persona_id)
    return {"status": "reset"}
