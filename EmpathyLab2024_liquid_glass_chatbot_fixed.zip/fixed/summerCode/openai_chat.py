import os
from typing import List, Optional, Tuple

import tiktoken
from openai import OpenAI


DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
MAX_HISTORY_TOKENS = int(os.getenv("MAX_HISTORY_TOKENS", "12000"))
DEFAULT_TEMPERATURE = float(os.getenv("OPENAI_TEMPERATURE", "0.6"))


def num_tokens_from_messages(messages: List[dict], model: str = DEFAULT_MODEL) -> int:
    try:
        encoding = tiktoken.encoding_for_model(model)
    except KeyError:
        encoding = tiktoken.get_encoding("cl100k_base")

    num_tokens = 0
    for message in messages:
        num_tokens += 4
        for key, value in message.items():
            if not isinstance(value, str):
                continue
            num_tokens += len(encoding.encode(value))
            if key == "name":
                num_tokens -= 1
    num_tokens += 2
    return num_tokens


class OpenAIChatService:
    def __init__(self, system_prompt: Optional[str] = None, model: str = DEFAULT_MODEL):
        self.model = model
        self.default_system_prompt = system_prompt or (
            "You are a helpful assistant for a modern website. Keep replies concise, accurate, and friendly."
        )
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY is not set.")
        self.client = OpenAI(api_key=api_key)

    def reset_history(self, system_prompt: Optional[str] = None) -> List[dict]:
        prompt = system_prompt or self.default_system_prompt
        return [{"role": "system", "content": prompt}]

    def _trim_history(self, history: List[dict]) -> List[dict]:
        trimmed = history[:]
        while len(trimmed) > 2 and num_tokens_from_messages(trimmed, self.model) > MAX_HISTORY_TOKENS:
            trimmed.pop(1)
        return trimmed

    def chat(
        self,
        message: str,
        history: Optional[List[dict]] = None,
        system_prompt: Optional[str] = None,
    ) -> Tuple[str, List[dict]]:
        prompt = system_prompt or self.default_system_prompt
        active_history = history[:] if history else self.reset_history(prompt)

        if not active_history or active_history[0].get("role") != "system":
            active_history = self.reset_history(prompt) + active_history
        else:
            active_history[0] = {"role": "system", "content": prompt}

        active_history.append({"role": "user", "content": message})
        active_history = self._trim_history(active_history)

        completion = self.client.chat.completions.create(
            model=self.model,
            messages=active_history,
            temperature=DEFAULT_TEMPERATURE,
        )

        reply = completion.choices[0].message.content or "I could not generate a reply."
        active_history.append({"role": "assistant", "content": reply})
        return reply, active_history
