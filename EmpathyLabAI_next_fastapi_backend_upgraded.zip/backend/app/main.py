from uuid import uuid4

from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware

from .models import ChatRequest, ChatResponse, ResetRequest, ResetResponse
from .services import ChatService
from .settings import get_settings
from .storage import MemoryConversationStore

settings = get_settings()
store = MemoryConversationStore(max_messages=settings.max_history_messages)
service = ChatService(settings=settings, store=store)

app = FastAPI(
    title=settings.app_name,
    version='0.2.0',
    docs_url='/docs',
    redoc_url='/redoc',
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)



def resolve_client_id(request: Request, incoming_client_id: str | None) -> str:
    if incoming_client_id:
        return incoming_client_id
    cookie_value = request.cookies.get(settings.session_cookie_name)
    if cookie_value:
        return cookie_value
    return str(uuid4())


@app.get('/')
def root() -> dict:
    return {
        'name': settings.app_name,
        'status': 'ok',
        'docs': '/docs',
        'mode': 'live' if settings.openai_api_key else 'demo',
    }


@app.get('/health')
def health() -> dict:
    return {
        'status': 'ok',
        'environment': settings.environment,
        'mode': 'live' if settings.openai_api_key else 'demo',
        'allowed_origins': settings.allowed_origins,
    }


@app.get('/api/personas')
def personas() -> dict:
    return {'personas': service.get_personas()}


@app.get('/api/config')
def config() -> dict:
    return {
        'app_name': settings.app_name,
        'mode': 'live' if settings.openai_api_key else 'demo',
        'session_cookie_name': settings.session_cookie_name,
    }


@app.post('/api/chat', response_model=ChatResponse)
def chat(request: Request, payload: ChatRequest, response: Response) -> ChatResponse:
    client_id = resolve_client_id(request, payload.client_id)
    try:
        result = service.chat(
            client_id=client_id,
            persona_id=payload.persona_id,
            message=payload.message.strip(),
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    response.set_cookie(
        key=settings.session_cookie_name,
        value=client_id,
        httponly=False,
        secure=False,
        samesite='lax',
        max_age=60 * 60 * 24 * 30,
    )
    return ChatResponse(**result)


@app.post('/api/reset', response_model=ResetResponse)
def reset(request: Request, payload: ResetRequest, response: Response) -> ResetResponse:
    client_id = resolve_client_id(request, payload.client_id)
    service.reset(client_id=client_id, persona_id=payload.persona_id)
    response.set_cookie(
        key=settings.session_cookie_name,
        value=client_id,
        httponly=False,
        secure=False,
        samesite='lax',
        max_age=60 * 60 * 24 * 30,
    )
    return ResetResponse(status='reset', client_id=client_id, persona_id=payload.persona_id)
