import os
from typing import Dict, List

import requests

from .personas import PERSONAS

ConversationStore = Dict[str, List[dict]]
conversation_store: ConversationStore = {}


class ChatService:
    def __init__(self) -> None:
        self.api_key = os.getenv("OPENAI_API_KEY", "").strip()
        self.model = os.getenv("OPENAI_MODEL", "gpt-4o-mini").strip() or "gpt-4o-mini"

    def _conversation_key(self, client_id: str, persona_id: str) -> str:
        return f"{client_id}:{persona_id}"

    def reset(self, client_id: str, persona_id: str) -> None:
        conversation_store[self._conversation_key(client_id, persona_id)] = []

    def get_personas(self) -> List[dict]:
        return [
            {k: v for k, v in persona.items() if k != "system_prompt"}
            for persona in PERSONAS.values()
        ]

    def chat(self, client_id: str, persona_id: str, message: str) -> dict:
        persona = PERSONAS.get(persona_id)
        if not persona:
            raise ValueError("Unknown persona_id")

        key = self._conversation_key(client_id, persona_id)
        history = conversation_store.setdefault(key, [])
        history.append({"role": "user", "content": message})

        if not self.api_key:
            reply = self._demo_reply(persona=persona, user_message=message)
            history.append({"role": "assistant", "content": reply})
            history[:] = history[-12:]
            return {"reply": reply, "mode": "demo"}

        system_message = {
            "role": "system",
            "content": (
                persona["system_prompt"]
                + " You are part of an educational empathy platform. Keep answers concise but helpful. "
                + "Do not provide medical diagnosis or emergency advice."
            ),
        }
        messages = [system_message] + history[-10:]
        payload = {"model": self.model, "messages": messages, "temperature": 0.8}
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        response = requests.post(
            "https://api.openai.com/v1/chat/completions",
            json=payload,
            headers=headers,
            timeout=60,
        )
        if response.status_code >= 400:
            raise RuntimeError(response.text)

        data = response.json()
        reply = data["choices"][0]["message"]["content"].strip()
        history.append({"role": "assistant", "content": reply})
        history[:] = history[-12:]
        return {"reply": reply, "mode": "live"}

    def _demo_reply(self, persona: dict, user_message: str) -> str:
        name = persona["name"]
        lower = user_message.lower()

        if "hello" in lower or "hi" in lower:
            return f"Hi, I am {name}. This is demo mode, but the flow is working. Ask me about symptoms, lived experience, or how this project supports empathy development."
        if "adhd" in lower:
            return (
                f"{name} here. In demo mode, I can still reflect the structure of the real experience. "
                "ADHD often affects attention regulation, task initiation, organization, and follow-through, but it can show up differently from person to person."
            )
        if "ocd" in lower:
            return (
                f"{name} here. OCD is not just about liking order. It involves intrusive thoughts, anxiety, and repetitive behaviors or mental rituals that people may feel driven to perform."
            )
        return (
            f"{name} received your question: '{user_message}'. The backend is running in demo mode because no OPENAI_API_KEY is configured yet. "
            "Once you add a key, this same interface will return live model responses while keeping the browser-based voice path."
        )
