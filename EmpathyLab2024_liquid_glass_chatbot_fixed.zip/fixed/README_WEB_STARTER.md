# Empathy Lab AI Web Platform

This fixed version turns the earlier prototype into a research showcase and integrated web app that can support the upgrade plan discussed in chat:

- premium liquid-glass landing page
- integrated chatbot section on the main site
- persona switching for Andrea Miller, Dr. Candice Martinez, and Cooper Litt
- browser voice input where supported
- browser speech synthesis output to avoid per-reply cloud TTS billing
- iframe-ready `/embed/chat` route for B12 or another site builder
- optional external embed target through `CHATBOT_EMBED_URL`
- demo fallback mode when `OPENAI_API_KEY` is not configured

## Core routes

- `/` full research and product showcase site
- `/embed/chat` embeddable chatbot module for B12 or another website
- `/api/chat` JSON chat endpoint
- `/api/reset` reset conversation state for a persona
- `/api/personas` persona metadata
- `/health` health check

## Environment variables

Copy `.env.example` to `.env` and update values as needed.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements_web.txt
cp .env.example .env
python app.py
```

Then open `http://127.0.0.1:5000`.

## How the chatbot integration works

### Native site demo
The main landing page includes a built-in chat panel with:

- persona selector
- text input
- optional browser microphone input
- browser speech synthesis for reply playback

### B12 embed route
Use the included embed route inside B12 or another builder that accepts iframes.

```html
<iframe
  src="https://your-domain.com/embed/chat"
  title="Empathy Lab AI Chat"
  width="100%"
  height="760"
  style="border:0;border-radius:32px;overflow:hidden;"
></iframe>
```

### External app handoff
If you later host a separate production chatbot, set:

```env
CHATBOT_EMBED_URL=https://your-chatbot-domain.com
```

The landing page will then show that external app inside the embed panel and add a launch button to open it in a new tab.

## Why browser speech is the default

This repo avoids calling ElevenLabs on every response in the live website path. That keeps spoken playback from consuming paid cloud TTS usage per reply.

If you want premium cloned voice later, you can:

1. accept per-request cloud usage, or
2. self-host a local voice stack and wire it into the backend.

## Demo fallback mode

If `OPENAI_API_KEY` is missing and `ENABLE_DEMO_FALLBACK=true`, the chatbot still responds with simplified persona-aware demo answers. That is useful for design review, embedding tests, and stakeholder walkthroughs.

## Files added or upgraded

- `app.py`
- `templates/index.html`
- `templates/embed_chat.html`
- `static/css/styles.css`
- `static/js/app.js`
- `summerCode/openai_chat.py`
- `B12_EMBED_SNIPPET.html`
- `.env.example`

## Recommended next upgrades

1. add persistent storage instead of in-memory session history
2. add streaming responses
3. add auth if the project is going public
4. add analytics and event tracking for empathy study workflows
5. replace demo fallback with a fuller offline local model path if needed
